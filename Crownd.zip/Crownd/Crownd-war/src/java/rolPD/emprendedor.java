package rolPD;

public class emprendedor {
    private int Id;
    private int IdUser;
    private int IdProject;

    public emprendedor(int Id, int IdUser, int IdProject) {
        this.Id = Id;
        this.IdUser = IdUser;
        this.IdProject = IdProject;
    }
    
    public emprendedor(){
        
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public int getIdUser() {
        return IdUser;
    }

    public void setIdUser(int IdUser) {
        this.IdUser = IdUser;
    }

    public int getIdProject() {
        return IdProject;
    }

    public void setIdProject(int IdProject) {
        this.IdProject = IdProject;
    }
    
    
}
