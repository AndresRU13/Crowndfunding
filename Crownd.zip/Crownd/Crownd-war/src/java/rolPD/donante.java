package rolPD;

public class donante {
    private int Id;
    private int IdUser;
    private int IdProject;

    public donante(int Id, int IdUser, int IdProject) {
        this.Id = Id;
        this.IdUser = IdUser;
        this.IdProject = IdProject;
    }
    
    public donante(){
        
    }

    public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public int getIdUser() {
        return IdUser;
    }

    public void setIdUser(int IdUser) {
        this.IdUser = IdUser;
    }

    public int getIdProject() {
        return IdProject;
    }

    public void setIdProject(int IdProject) {
        this.IdProject = IdProject;
    }
    
    

}
