/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servlet;

import dao.donanteDaoLocal;
import dao.projectDaoLocal;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import rolPD.donante;

/**
 *
 * @author larra
 */
public class AprovCierreProyServlet extends HttpServlet {

    @EJB
    private projectDaoLocal projectDao;
    private donanteDaoLocal donanteDao;

    
    
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        String status = "";
        String proyName ="";
        int proyID = 0;
        
        proyName = request.getParameter("Nombre");
        
        String idStr = request.getParameter("id");
        int id = 0;
        if(idStr!=null && !idStr.equals(""))
            id = Integer.parseInt(idStr);
        
        int cont = projectDao.projects().size();
        
        String proyectoIdStr = request.getParameter("proyectoId");
        int proyectoId = 0;
        if(proyectoIdStr!=null && !proyectoIdStr.equals(""))
            proyectoId = Integer.parseInt(proyectoIdStr);
        
        String donanteIdStr = request.getParameter("usuarioId");
        int donanteId = 0;
        if(donanteIdStr!=null && !donanteIdStr.equals(""))
            donanteId = Integer.parseInt(donanteIdStr);
        
        for(int i = 0; i < cont;){
            if(proyName.equals(projectDao.searchproject(proyID))){
                status = projectDao.searchproject(proyID).getEstado();
            }else{
                proyID = i+1;
            }
        }
        
        donante don = new donante(id, donanteId, proyectoId);
        
        request.setAttribute("donante", don);
        request.setAttribute("allProjects", donanteDao.projects());
        
        //Modificar el estado, modificarlo después de saber como funcionan las notificaciones a donantes por parte del emprendedor
        if(!status.equalsIgnoreCase("Cerrado") || !status.equalsIgnoreCase("Cancelado")){//abierto a modificación, siempre que signifique lo mismo
            projectDao.searchproject(proyID).setEstado("Cerrado");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
