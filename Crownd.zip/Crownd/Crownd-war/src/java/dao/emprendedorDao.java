package dao;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import proyecto.project;

@Stateless
public class emprendedorDao implements emprendedorDaoLocal {
    @PersistenceContext
    private EntityManager em;
    
    @Override
    public void deleteproject(int projectId) {
        em.remove(projectId);
    }
    
    @Override
    public List<project> projects() {
        return em.createNamedQuery("project.getAll").getResultList();
    }
    
}
