package dao;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import usuario.user;

@Stateless
public class userDao implements userDaoLocal {
    @PersistenceContext
    private EntityManager em;
    
    
    @Override
    public void addUser(user usuario) {
        em.persist(usuario);
    }

    @Override
    public void updateUser(user usuario) {
        em.merge(usuario);
    }

    @Override
    public void deleteUser(int usuarioId) {
        em.remove(usuarioId);
    }

    @Override
    public user searchUser(int usuarioId) {
        return em.find(user.class, usuarioId);
    }

    @Override
    public List<user> users() {
        return em.createNamedQuery("user.getAll").getResultList();
    }
    
}
