package dao;

import java.util.List;
import javax.ejb.Local;
import proyecto.project;

@Local
public interface emprendedorDaoLocal {
    
    void deleteproject(int projectId);
    
    List<project> projects();
}
