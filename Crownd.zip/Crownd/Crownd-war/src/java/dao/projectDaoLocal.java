package dao;

import java.util.List;
import javax.ejb.Local;
import proyecto.project;

@Local
public interface projectDaoLocal {

    void addproject(project proyecto);

    void editproject(project proyecto);

    void deleteproject(int projectId);

    project searchproject(int projectId);

    List<project> projects();
    
}
