package dao;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import proyecto.project;

@Stateless
public class donanteDao implements donanteDaoLocal {
    @PersistenceContext
    private EntityManager dn;

    @Override
    public void addProject(int id, String estado) {
    }

    @Override
    public List<project> projects() {
        return dn.createNamedQuery("project.getAll").getResultList();
    }
    
    
}
