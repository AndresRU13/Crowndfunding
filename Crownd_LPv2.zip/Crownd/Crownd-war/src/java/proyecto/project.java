package proyecto;

import java.io.Serializable;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table
@NamedQueries(@NamedQuery(name="user.getAll", query="SELECT e FROM user e"))
public class project implements Serializable {
    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column
    private int projectId;
    @Column
    private String name;
    @Column
    private String descripcion;
    @Column
    private Date f_Inicio;
    @Column
    private Date f_Final;
    @Column
    private String estado;

    public project(int projectId, String name, String descripcion, Date f_Inicio, Date f_Final, String estado) {
        this.projectId = projectId;
        this.name = name;
        this.descripcion = descripcion;
        this.f_Inicio = f_Inicio;
        this.f_Final = f_Final;
        this.estado = estado;
    }
    
    public project(){
        
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Date getF_Inicio() {
        return f_Inicio;
    }

    public void setF_Inicio(Date f_Inicio) {
        this.f_Inicio = f_Inicio;
    }

    public Date getF_Final() {
        return f_Final;
    }

    public void setF_Final(Date f_Final) {
        this.f_Final = f_Final;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
}