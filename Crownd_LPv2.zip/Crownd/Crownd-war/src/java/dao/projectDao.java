package dao;

import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import proyecto.project;

@Stateless
public class projectDao implements projectDaoLocal {
    @PersistenceContext
    private EntityManager pr;

    @Override
    public void addproject(project proyecto) {
        pr.persist(proyecto);
    }

    @Override
    public void editproject(project proyecto) {
        pr.merge(proyecto);
    }

    @Override
    public void deleteproject(int projectId) {
        pr.remove(projectId);
    }

    @Override
    public project searchproject(int projectId) {
        return pr.find(project.class, projectId);
    }

    @Override
    public List<project> projects() {
        return pr.createNamedQuery("project.getAll").getResultList();
    }
    
    
}
