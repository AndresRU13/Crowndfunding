package dao;

import java.util.List;
import javax.ejb.Local;
import usuario.user;

/**
 *
 * @author Usuario
 */
@Local
public interface userDaoLocal {

    void addUser(user usuario);

    void updateUser(user usuario);

    void deleteUser(int usuarioId);

    user searchUser(int usuarioId);

    List<user> users();
    
}
